/* ============================================================
   RED HOT SERVICE — vanilla JS
   IntersectionObserver reveals, counters, parallax,
   mobile menu, smooth FAQ, header behaviour
   ============================================================ */
(function () {
  'use strict';

  var prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var isCoarsePointer = window.matchMedia('(pointer: coarse)').matches;

  /* ---------- Hero entrance ---------- */
  function markLoaded() {
    document.body.classList.add('is-loaded');
  }
  if (document.readyState === 'complete') {
    markLoaded();
  } else {
    window.addEventListener('load', markLoaded);
    // Fallback: never leave the hero hidden if load is delayed
    setTimeout(markLoaded, 1800);
  }

  /* ---------- Header: background + hide on scroll down ---------- */
  var header = document.getElementById('header');
  var lastScrollY = window.scrollY;
  var headerTicking = false;

  function updateHeader() {
    var y = window.scrollY;
    header.classList.toggle('header--scrolled', y > 24);
    if (y > 320 && y > lastScrollY + 4 && !document.body.classList.contains('menu-open')) {
      header.classList.add('header--hidden');
    } else if (y < lastScrollY - 4 || y <= 320) {
      header.classList.remove('header--hidden');
    }
    lastScrollY = y;
    headerTicking = false;
  }

  window.addEventListener('scroll', function () {
    if (!headerTicking) {
      headerTicking = true;
      requestAnimationFrame(updateHeader);
    }
  }, { passive: true });

  /* ---------- Mobile menu ---------- */
  var burger = document.getElementById('burger');
  var mobileMenu = document.getElementById('mobileMenu');

  function setMenu(open) {
    burger.classList.toggle('header__burger--open', open);
    mobileMenu.classList.toggle('mobile-menu--open', open);
    document.body.classList.toggle('menu-open', open);
    document.body.style.overflow = open ? 'hidden' : '';
    burger.setAttribute('aria-expanded', String(open));
    burger.setAttribute('aria-label', open ? 'Закрыть меню' : 'Открыть меню');
    mobileMenu.setAttribute('aria-hidden', String(!open));
  }

  burger.addEventListener('click', function () {
    setMenu(!mobileMenu.classList.contains('mobile-menu--open'));
  });

  mobileMenu.querySelectorAll('a').forEach(function (link) {
    link.addEventListener('click', function () { setMenu(false); });
  });

  window.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && mobileMenu.classList.contains('mobile-menu--open')) {
      setMenu(false);
      burger.focus();
    }
  });

  /* ---------- Scroll reveal with stagger ---------- */
  var revealEls = Array.prototype.slice.call(document.querySelectorAll('[data-reveal]'));

  if (prefersReducedMotion || !('IntersectionObserver' in window)) {
    revealEls.forEach(function (el) { el.classList.add('is-visible'); });
  } else {
    // Stagger siblings that share the same parent grid
    var groups = new Map();
    revealEls.forEach(function (el) {
      var parent = el.parentElement;
      if (!groups.has(parent)) groups.set(parent, 0);
      var index = groups.get(parent);
      groups.set(parent, index + 1);
      if (index > 0) {
        el.style.setProperty('--reveal-delay', Math.min(index * 0.09, 0.45) + 's');
      }
    });

    var revealObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          revealObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });

    revealEls.forEach(function (el) { revealObserver.observe(el); });
  }

  /* ---------- Animated counters ---------- */
  var counters = Array.prototype.slice.call(document.querySelectorAll('[data-counter]'));

  function animateCounter(el) {
    var target = parseFloat(el.getAttribute('data-counter'));
    var decimals = parseInt(el.getAttribute('data-decimals') || '0', 10);
    if (prefersReducedMotion) {
      el.textContent = target.toFixed(decimals).replace('.', ',');
      return;
    }
    var duration = 1600;
    var start = null;

    function frame(now) {
      if (start === null) start = now;
      var progress = Math.min((now - start) / duration, 1);
      // easeOutExpo
      var eased = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
      var value = target * eased;
      el.textContent = value.toFixed(decimals).replace('.', ',');
      if (progress < 1) requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }

  if ('IntersectionObserver' in window) {
    var counterObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          animateCounter(entry.target);
          counterObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.6 });
    counters.forEach(function (el) { counterObserver.observe(el); });
  } else {
    counters.forEach(animateCounter);
  }

  /* ---------- Hero parallax ---------- */
  var heroBg = document.getElementById('heroBg');
  var hero = document.getElementById('hero');

  if (heroBg && !prefersReducedMotion && !isCoarsePointer) {
    var parallaxTicking = false;
    window.addEventListener('scroll', function () {
      if (parallaxTicking) return;
      parallaxTicking = true;
      requestAnimationFrame(function () {
        var y = window.scrollY;
        var limit = hero.offsetHeight;
        if (y < limit) {
          heroBg.style.transform = 'translate3d(0,' + (y * 0.22).toFixed(1) + 'px,0)';
        }
        parallaxTicking = false;
      });
    }, { passive: true });
  }

  /* ---------- FAQ: smooth open / close ---------- */
  document.querySelectorAll('.faq__item').forEach(function (item) {
    var summary = item.querySelector('summary');
    var answer = item.querySelector('.faq__answer');
    if (!summary || !answer) return;

    summary.addEventListener('click', function (e) {
      if (prefersReducedMotion) return; // native toggle
      e.preventDefault();

      if (item.open) {
        var closeAnim = answer.animate(
          [{ height: answer.scrollHeight + 'px', opacity: 1 }, { height: '0px', opacity: 0 }],
          { duration: 320, easing: 'cubic-bezier(0.83, 0, 0.17, 1)' }
        );
        closeAnim.onfinish = function () { item.open = false; };
      } else {
        item.open = true;
        answer.animate(
          [{ height: '0px', opacity: 0 }, { height: answer.scrollHeight + 'px', opacity: 1 }],
          { duration: 420, easing: 'cubic-bezier(0.22, 1, 0.36, 1)' }
        );
      }
    });
  });

  /* ---------- Active nav link on scroll ---------- */
  var navLinks = Array.prototype.slice.call(document.querySelectorAll('.header__link'));
  var sections = navLinks
    .map(function (link) {
      var id = link.getAttribute('href');
      return id && id.charAt(0) === '#' ? document.querySelector(id) : null;
    })
    .filter(Boolean);

  if ('IntersectionObserver' in window && sections.length) {
    var navObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          navLinks.forEach(function (link) {
            link.classList.toggle(
              'header__link--active',
              link.getAttribute('href') === '#' + entry.target.id
            );
          });
        }
      });
    }, { rootMargin: '-40% 0px -55% 0px' });
    sections.forEach(function (section) { navObserver.observe(section); });
  }

  /* ---------- Footer year ---------- */
  var yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = String(new Date().getFullYear());
})();
